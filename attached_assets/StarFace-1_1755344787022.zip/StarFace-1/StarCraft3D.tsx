
import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import './StarCraft3D.css';

interface Block {
  type: string;
  x: number;
  y: number;
  z: number;
  metadata?: any;
  light?: number;
  texture?: string;
}

interface Player {
  x: number;
  y: number;
  z: number;
  health: number;
  hunger: number;
  experience: number;
  level: number;
  stamina: number;
  temperature: number;
  biome: string;
  direction: number;
  gameMode: 'survival' | 'creative' | 'adventure' | 'spectator';
}

interface InventoryItem {
  type: string;
  count: number;
  durability?: number;
  maxDurability?: number;
  enchantments?: string[];
  texture?: string;
}

interface NPC {
  id: string;
  x: number;
  y: number;
  z: number;
  type: string;
  health: number;
  inventory: InventoryItem[];
  ai?: any;
}

interface Particle {
  id: string;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  color: string;
  size: number;
}

const minecraftTextures = {
  // Basic blocks
  air: { emoji: '🌫️', texture: 'air', color: 'transparent' },
  grass: { emoji: '🟩', texture: 'grass_block_top', color: '#7cb342' },
  dirt: { emoji: '🟫', texture: 'dirt', color: '#8d6e63' },
  stone: { emoji: '⬜', texture: 'stone', color: '#757575' },
  cobblestone: { emoji: '🪨', texture: 'cobblestone', color: '#696969' },
  bedrock: { emoji: '⬛', texture: 'bedrock', color: '#212121' },
  
  // Wood types
  oak_log: { emoji: '🪵', texture: 'oak_log', color: '#8d6e63' },
  spruce_log: { emoji: '🌲', texture: 'spruce_log', color: '#5d4037' },
  birch_log: { emoji: '🌳', texture: 'birch_log', color: '#f5f5dc' },
  jungle_log: { emoji: '🌴', texture: 'jungle_log', color: '#6b8e23' },
  
  // Planks
  oak_planks: { emoji: '📦', texture: 'oak_planks', color: '#daa520' },
  spruce_planks: { emoji: '🟫', texture: 'spruce_planks', color: '#8b4513' },
  birch_planks: { emoji: '🟨', texture: 'birch_planks', color: '#f5deb3' },
  jungle_planks: { emoji: '🟤', texture: 'jungle_planks', color: '#cd853f' },
  
  // Ores
  coal_ore: { emoji: '⚫', texture: 'coal_ore', color: '#424242' },
  iron_ore: { emoji: '🤎', texture: 'iron_ore', color: '#d2b48c' },
  gold_ore: { emoji: '🟡', texture: 'gold_ore', color: '#ffd700' },
  diamond_ore: { emoji: '💎', texture: 'diamond_ore', color: '#00bcd4' },
  emerald_ore: { emoji: '🟢', texture: 'emerald_ore', color: '#50c878' },
  redstone_ore: { emoji: '🔴', texture: 'redstone_ore', color: '#dc143c' },
  
  // Blocks
  coal_block: { emoji: '⚫', texture: 'coal_block', color: '#2f2f2f' },
  iron_block: { emoji: '⚪', texture: 'iron_block', color: '#d3d3d3' },
  gold_block: { emoji: '🟨', texture: 'gold_block', color: '#ffd700' },
  diamond_block: { emoji: '💎', texture: 'diamond_block', color: '#b0e0e6' },
  emerald_block: { emoji: '💚', texture: 'emerald_block', color: '#50c878' },
  
  // Glass
  glass: { emoji: '🔷', texture: 'glass', color: 'rgba(173, 216, 230, 0.7)' },
  white_stained_glass: { emoji: '⚪', texture: 'white_stained_glass', color: 'rgba(255, 255, 255, 0.7)' },
  red_stained_glass: { emoji: '🔴', texture: 'red_stained_glass', color: 'rgba(255, 0, 0, 0.7)' },
  green_stained_glass: { emoji: '🟢', texture: 'green_stained_glass', color: 'rgba(0, 128, 0, 0.7)' },
  blue_stained_glass: { emoji: '🔵', texture: 'blue_stained_glass', color: 'rgba(0, 0, 255, 0.7)' },
  
  // Wool
  white_wool: { emoji: '⚪', texture: 'white_wool', color: '#ffffff' },
  red_wool: { emoji: '🔴', texture: 'red_wool', color: '#ff0000' },
  green_wool: { emoji: '🟢', texture: 'green_wool', color: '#008000' },
  blue_wool: { emoji: '🔵', texture: 'blue_wool', color: '#0000ff' },
  
  // Natural
  water: { emoji: '💧', texture: 'water', color: '#2196f3' },
  lava: { emoji: '🔥', texture: 'lava', color: '#ff4500' },
  sand: { emoji: '🏖️', texture: 'sand', color: '#ffcc80' },
  gravel: { emoji: '⚫', texture: 'gravel', color: '#808080' },
  
  // Lighting
  torch: { emoji: '🕯️', texture: 'torch', color: '#ffaa00' },
  glowstone: { emoji: '💡', texture: 'glowstone', color: '#ffff8c' },
  lantern: { emoji: '🏮', texture: 'lantern', color: '#ffd700' },
  
  // Functional
  crafting_table: { emoji: '🔨', texture: 'crafting_table_front', color: '#cd853f' },
  furnace: { emoji: '🔥', texture: 'furnace_front', color: '#666666' },
  chest: { emoji: '📦', texture: 'chest_front', color: '#8b4513' },
  
  // Plants
  cactus: { emoji: '🌵', texture: 'cactus_side', color: '#228b22' },
  bamboo: { emoji: '🎋', texture: 'bamboo', color: '#9acd32' },
  
  // Flowers
  poppy: { emoji: '🌺', texture: 'poppy', color: '#ff0000' },
  dandelion: { emoji: '🌻', texture: 'dandelion', color: '#ffff00' },
  rose_bush: { emoji: '🌹', texture: 'rose_bush', color: '#ff1493' },
  
  // Special
  tnt: { emoji: '💣', texture: 'tnt_side', color: '#ff0000' },
  beacon: { emoji: '🔆', texture: 'beacon', color: '#87ceeb' },
  obsidian: { emoji: '⬜', texture: 'obsidian', color: '#2c1810' },
  
  // Nether
  netherrack: { emoji: '🔴', texture: 'netherrack', color: '#8b0000' },
  nether_bricks: { emoji: '🧱', texture: 'nether_bricks', color: '#800000' },
  soul_sand: { emoji: '👻', texture: 'soul_sand', color: '#8b7355' },
  
  // End
  end_stone: { emoji: '🟨', texture: 'end_stone', color: '#fffacd' },
  purpur_block: { emoji: '🟣', texture: 'purpur_block', color: '#a020f0' },
  
  // Leaves
  oak_leaves: { emoji: '🍃', texture: 'oak_leaves', color: '#228b22' },
  spruce_leaves: { emoji: '🌿', texture: 'spruce_leaves', color: '#2d5c2d' },
  birch_leaves: { emoji: '🌱', texture: 'birch_leaves', color: '#80c471' },
  jungle_leaves: { emoji: '🍀', texture: 'jungle_leaves', color: '#228b22' }
};

const biomes = {
  plains: { name: 'Plains', grassColor: '#7cb342', temperature: 20, blocks: ['grass', 'dirt', 'stone'] },
  forest: { name: 'Forest', grassColor: '#2e7d32', temperature: 15, blocks: ['oak_log', 'oak_planks', 'dirt'] },
  desert: { name: 'Desert', grassColor: '#ffcc80', temperature: 35, blocks: ['sand', 'cactus', 'stone'] },
  mountains: { name: 'Mountains', grassColor: '#6d4c41', temperature: 5, blocks: ['stone', 'cobblestone', 'coal_ore'] },
  ocean: { name: 'Ocean', grassColor: '#006994', temperature: 18, blocks: ['water', 'sand', 'gravel'] }
};

const WORLD_SIZE = { x: 25, y: 10, z: 25 };
const MOBILE_WORLD_SIZE = { x: 15, y: 8, z: 15 };

const StarCraft3D: React.FC = () => {
  const [isMobile, setIsMobile] = useState(false);
  const [world, setWorld] = useState<Block[][][]>([]);
  const [player, setPlayer] = useState<Player>({
    x: 25, y: 8, z: 25, health: 100, hunger: 100, experience: 0, level: 1,
    stamina: 100, temperature: 20, biome: 'plains', direction: 0, gameMode: 'creative'
  });
  const [inventory, setInventory] = useState<InventoryItem[]>([
    { type: 'diamond_pickaxe', count: 1, texture: '⛏️' },
    { type: 'grass', count: 64, texture: '🟩' },
    { type: 'stone', count: 64, texture: '⬜' },
    { type: 'oak_planks', count: 64, texture: '📦' },
    { type: 'torch', count: 32, texture: '🕯️' },
    { type: 'glass', count: 32, texture: '🔷' },
    { type: 'water', count: 16, texture: '💧' },
    { type: 'tnt', count: 8, texture: '💣' },
    { type: 'diamond_block', count: 16, texture: '💎' }
  ]);
  const [selectedItem, setSelectedItem] = useState(0);
  const [showInventory, setShowInventory] = useState(false);
  const [showCrafting, setShowCrafting] = useState(false);
  const [cameraAngle, setCameraAngle] = useState({ x: 60, y: 45, zoom: 0.8 });
  const [time, setTime] = useState(6000);
  const [weather, setWeather] = useState<'clear' | 'rain' | 'storm'>('clear');
  const [npcs, setNpcs] = useState<NPC[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [touchStart, setTouchStart] = useState<{ x: number; y: number } | null>(null);
  const [isBuilding, setIsBuilding] = useState(false);

  const gameLoopRef = useRef<NodeJS.Timeout>();
  const worldContainerRef = useRef<HTMLDivElement>(null);

  // Detect mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const currentWorldSize = isMobile ? MOBILE_WORLD_SIZE : WORLD_SIZE;

  // Optimized terrain generation
  const generateWorld = useCallback(() => {
    const newWorld: Block[][][] = [];
    
    // Initialize world with air more efficiently
    for (let x = 0; x < currentWorldSize.x; x++) {
      newWorld[x] = [];
      for (let y = 0; y < currentWorldSize.y; y++) {
        newWorld[x][y] = [];
        for (let z = 0; z < currentWorldSize.z; z++) {
          newWorld[x][y][z] = { type: 'air', x, y, z };
        }
      }
    }

    // Simplified heightmap generation
    const baseHeight = Math.floor(currentWorldSize.y * 0.5);
    const heightMap: number[][] = [];
    for (let x = 0; x < currentWorldSize.x; x++) {
      heightMap[x] = [];
      for (let z = 0; z < currentWorldSize.z; z++) {
        // Reduced noise complexity
        const noise = Math.sin(x * 0.1) * Math.cos(z * 0.1) * 2;
        heightMap[x][z] = Math.max(2, Math.min(currentWorldSize.y - 2, baseHeight + noise));
      }
    }

    // Simplified terrain placement
    for (let x = 0; x < currentWorldSize.x; x++) {
      for (let z = 0; z < currentWorldSize.z; z++) {
        const height = Math.floor(heightMap[x][z]);
        
        for (let y = 0; y < Math.min(height + 1, currentWorldSize.y); y++) {
          let blockType = 'air';
          
          if (y === 0) {
            blockType = 'bedrock';
          } else if (y < height - 2) {
            blockType = 'stone';
          } else if (y < height) {
            blockType = 'dirt';
          } else if (y === height) {
            blockType = 'grass';
          }

          if (blockType !== 'air') {
            newWorld[x][y][z] = {
              type: blockType,
              x, y, z,
              texture: minecraftTextures[blockType as keyof typeof minecraftTextures]?.texture
            };
          }
        }
      }
    }

    // Add some basic ores for variety (simplified)
    for (let x = 0; x < currentWorldSize.x; x += 3) {
      for (let z = 0; z < currentWorldSize.z; z += 3) {
        for (let y = 1; y < Math.min(heightMap[x][z] - 1, 8); y++) {
          if (newWorld[x] && newWorld[x][y] && newWorld[x][y][z] && 
              newWorld[x][y][z].type === 'stone' && Math.random() < 0.1) {
            newWorld[x][y][z].type = Math.random() < 0.5 ? 'coal_ore' : 'iron_ore';
          }
        }
      }
    }
    
    return newWorld;
  }, [currentWorldSize]);

  // Tree generation helper
  const generateTree = (world: Block[][][], x: number, y: number, z: number, worldSize: typeof currentWorldSize) => {
    const treeHeight = Math.floor(Math.random() * 3) + 4;
    const treeTypes = ['oak', 'spruce', 'birch', 'jungle'];
    const treeType = treeTypes[Math.floor(Math.random() * treeTypes.length)];
    
    // Generate trunk
    for (let ty = 0; ty < treeHeight && y + ty < worldSize.y; ty++) {
      if (world[x][y + ty][z].type === 'air') {
        world[x][y + ty][z] = {
          type: `${treeType}_log`,
          x, y: y + ty, z,
          texture: minecraftTextures[`${treeType}_log` as keyof typeof minecraftTextures]?.texture
        };
      }
    }
    
    // Generate leaves (simple crown)
    const crownY = y + treeHeight - 1;
    const leafType = `${treeType}_leaves`;
    
    for (let dx = -2; dx <= 2; dx++) {
      for (let dz = -2; dz <= 2; dz++) {
        for (let dy = -1; dy <= 1; dy++) {
          const leafX = x + dx;
          const leafZ = z + dz;
          const leafY = crownY + dy;
          
          if (leafX >= 0 && leafX < worldSize.x && 
              leafZ >= 0 && leafZ < worldSize.z && 
              leafY >= 0 && leafY < worldSize.y &&
              world[leafX][leafY][leafZ].type === 'air' &&
              (Math.abs(dx) + Math.abs(dz) < 3 || Math.random() < 0.7)) {
            
            // Add oak_planks as leaves since we don't have specific leaf textures
            world[leafX][leafY][leafZ] = {
              type: 'oak_planks',
              x: leafX, y: leafY, z: leafZ,
              texture: minecraftTextures['oak_planks']?.texture
            };
          }
        }
      }
    }
  };

  // Initialize world
  useEffect(() => {
    const newWorld = generateWorld();
    setWorld(newWorld);
    
    const centerX = Math.floor(currentWorldSize.x / 2);
    const centerZ = Math.floor(currentWorldSize.z / 2);
    
    // Find the surface height at spawn position
    let spawnY = currentWorldSize.y - 1;
    for (let y = currentWorldSize.y - 1; y >= 0; y--) {
      if (newWorld[centerX] && newWorld[centerX][y] && newWorld[centerX][y][centerZ] && 
          newWorld[centerX][y][centerZ].type !== 'air') {
        spawnY = y + 2; // Place player 2 blocks above surface
        break;
      }
    }
    
    setPlayer(prev => ({
      ...prev,
      x: centerX,
      y: spawnY,
      z: centerZ
    }));
  }, [generateWorld, currentWorldSize]);

  // Optimized game loop
  useEffect(() => {
    gameLoopRef.current = setInterval(() => {
      setTime(prev => (prev + 10) % 24000); // Slower time progression
      
      // Less frequent weather changes
      if (Math.random() < 0.0001) {
        const weathers: Array<'clear' | 'rain' | 'storm'> = ['clear', 'rain', 'storm'];
        setWeather(weathers[Math.floor(Math.random() * weathers.length)]);
      }
    }, 500); // Reduced frequency

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
    };
  }, []);

  // Movement
  const movePlayer = useCallback((dx: number, dy: number, dz: number) => {
    setPlayer(prev => {
      const newX = Math.max(0, Math.min(prev.x + dx, currentWorldSize.x - 1));
      const newY = Math.max(1, Math.min(prev.y + dy, currentWorldSize.y - 1));
      const newZ = Math.max(0, Math.min(prev.z + dz, currentWorldSize.z - 1));

      // Check collision
      if (world[newX] && world[newX][newY] && world[newX][newY][newZ] && 
          world[newX][newY][newZ].type !== 'air') {
        return prev;
      }

      return { ...prev, x: newX, y: newY, z: newZ };
    });
  }, [world, currentWorldSize]);

  // Block interaction
  const mineBlock = useCallback((x: number, y: number, z: number) => {
    if (y === 0 || !world[x] || !world[x][y] || !world[x][y][z]) return;
    
    const block = world[x][y][z];
    if (block.type === 'air') return;

    // Add to inventory
    const existingItem = inventory.find(item => item.type === block.type);
    if (existingItem) {
      existingItem.count += 1;
    } else {
      setInventory(prev => [...prev, { 
        type: block.type, 
        count: 1, 
        texture: minecraftTextures[block.type as keyof typeof minecraftTextures]?.emoji 
      }]);
    }

    // Remove block
    setWorld(prev => {
      const newWorld = prev.map(layer => layer.map(row => [...row]));
      newWorld[x][y][z] = { type: 'air', x, y, z };
      return newWorld;
    });

    // Add particles
    addParticles(x, y, z, 'mine');
  }, [world, inventory]);

  const placeBlock = useCallback((x: number, y: number, z: number) => {
    const currentItem = inventory[selectedItem];
    if (!currentItem || currentItem.count <= 0) return;

    if (!world[x] || !world[x][y] || !world[x][y][z] || world[x][y][z].type !== 'air') return;

    setWorld(prev => {
      const newWorld = prev.map(layer => layer.map(row => [...row]));
      newWorld[x][y][z] = { 
        type: currentItem.type, 
        x, y, z,
        texture: minecraftTextures[currentItem.type as keyof typeof minecraftTextures]?.texture
      };
      return newWorld;
    });

    setInventory(prev => prev.map((item, index) => 
      index === selectedItem ? { ...item, count: item.count - 1 } : item
    ).filter(item => item.count > 0));

    addParticles(x, y, z, 'place');
  }, [world, inventory, selectedItem]);

  // Particles
  const addParticles = useCallback((x: number, y: number, z: number, type: string) => {
    const newParticles: Particle[] = [];
    for (let i = 0; i < 6; i++) {
      newParticles.push({
        id: `${type}_${Date.now()}_${i}`,
        x: x + Math.random() - 0.5,
        y: y + Math.random() - 0.5,
        z: z + Math.random() - 0.5,
        vx: (Math.random() - 0.5) * 0.2,
        vy: Math.random() * 0.3,
        vz: (Math.random() - 0.5) * 0.2,
        life: 30,
        color: type === 'mine' ? '#8B4513' : '#32CD32',
        size: 2
      });
    }
    setParticles(prev => [...prev, ...newParticles].slice(-50));
  }, []);

  // Update particles
  useEffect(() => {
    const interval = setInterval(() => {
      setParticles(prev => prev.map(p => ({
        ...p,
        x: p.x + p.vx,
        y: p.y + p.vy,
        z: p.z + p.vz,
        vy: p.vy - 0.01,
        life: p.life - 1
      })).filter(p => p.life > 0));
    }, 50);
    
    return () => clearInterval(interval);
  }, []);

  // Touch controls
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    setTouchStart({ x: touch.clientX, y: touch.clientY });
  }, []);

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    if (!touchStart) return;
    
    const touch = e.changedTouches[0];
    const deltaX = touch.clientX - touchStart.x;
    const deltaY = touch.clientY - touchStart.y;
    
    if (Math.abs(deltaX) > Math.abs(deltaY)) {
      if (deltaX > 50) movePlayer(1, 0, 0);
      else if (deltaX < -50) movePlayer(-1, 0, 0);
    } else {
      if (deltaY > 50) movePlayer(0, 0, 1);
      else if (deltaY < -50) movePlayer(0, 0, -1);
    }
    
    setTouchStart(null);
  }, [touchStart, movePlayer]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key.toLowerCase()) {
        case 'w': movePlayer(0, 0, -1); break;
        case 's': movePlayer(0, 0, 1); break;
        case 'a': movePlayer(-1, 0, 0); break;
        case 'd': movePlayer(1, 0, 0); break;
        case ' ': e.preventDefault(); movePlayer(0, 1, 0); break;
        case 'shift': movePlayer(0, -1, 0); break;
        case 'e': setShowInventory(prev => !prev); break;
        case 'c': setShowCrafting(prev => !prev); break;
        case 'b': setIsBuilding(prev => !prev); break;
      }
      
      if (e.key >= '1' && e.key <= '9') {
        setSelectedItem(parseInt(e.key) - 1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [movePlayer]);

  // Optimized visible blocks calculation
  const visibleBlocks = useMemo(() => {
    const blocks = [];
    const viewDistance = isMobile ? 8 : 12; // Reduced view distance
    
    // Only render blocks around player position
    const startX = Math.max(0, player.x - viewDistance);
    const endX = Math.min(currentWorldSize.x, player.x + viewDistance);
    const startZ = Math.max(0, player.z - viewDistance);
    const endZ = Math.min(currentWorldSize.z, player.z + viewDistance);
    
    for (let x = startX; x < endX; x++) {
      for (let z = startZ; z < endZ; z++) {
        for (let y = Math.max(0, player.y - 5); y < Math.min(currentWorldSize.y, player.y + 5); y++) {
          if (world[x] && world[x][y] && world[x][y][z] && world[x][y][z].type !== 'air') {
            // Distance culling for better performance
            const distance = Math.abs(x - player.x) + Math.abs(z - player.z) + Math.abs(y - player.y);
            if (distance < viewDistance) {
              blocks.push(world[x][y][z]);
            }
          }
        }
      }
    }
    
    return blocks;
  }, [world, player, currentWorldSize, isMobile]);

  const isDaytime = time >= 0 && time < 12000;
  const lightLevel = isDaytime ? 1 : 0.3;

  return (
    <div 
      className={`minecraft-world ${isMobile ? 'mobile' : 'desktop'}`}
      style={{ filter: `brightness(${lightLevel})` }}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* HUD */}
      <div className="hud">
        <div className="hud-top">
          <div className="health">❤️ {Math.ceil(player.health)}</div>
          <div className="hunger">🍖 {Math.ceil(player.hunger)}</div>
          <div className="level">⭐ Level {player.level}</div>
        </div>
        <div className="hud-bottom">
          <div className="biome">🗺️ {player.biome}</div>
          <div className="time">{isDaytime ? '☀️' : '🌙'} {Math.floor(time / 1000)}:00</div>
          <div className="weather">
            {weather === 'clear' && '☀️'}
            {weather === 'rain' && '🌧️'}
            {weather === 'storm' && '⛈️'}
            {weather}
          </div>
        </div>
      </div>

      {/* Debug Info */}
      <div className="debug-info">
        <div>Player: ({player.x}, {player.y}, {player.z})</div>
        <div>Visible Blocks: {visibleBlocks.length}</div>
        <div>World Size: {currentWorldSize.x}×{currentWorldSize.y}×{currentWorldSize.z}</div>
        <div>Camera: x{cameraAngle.x}° y{cameraAngle.y}° zoom{cameraAngle.zoom}</div>
      </div>

      {/* Hotbar */}
      <div className="hotbar">
        {Array.from({ length: Math.min(9, inventory.length) }).map((_, index) => (
          <div
            key={index}
            className={`hotbar-slot ${index === selectedItem ? 'selected' : ''}`}
            onClick={() => setSelectedItem(index)}
          >
            {inventory[index] && (
              <div className="item">
                <div className="item-texture">
                  {minecraftTextures[inventory[index].type as keyof typeof minecraftTextures]?.emoji || '📦'}
                </div>
                <span className="item-count">{inventory[index].count}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* World Container */}
      <div 
        ref={worldContainerRef}
        className="world-container"
        style={{ perspective: isMobile ? '800px' : '1200px' }}
      >
        <div 
          className="world-view"
          style={{
            transform: `
              rotateX(${cameraAngle.x}deg) 
              rotateY(${cameraAngle.y}deg) 
              scale(${cameraAngle.zoom}) 
              translate3d(-${player.x * (isMobile ? 15 : 20)}px, -${player.y * (isMobile ? 15 : 20)}px, -${player.z * (isMobile ? 15 : 20)}px)
            `
          }}
        >
          {/* Player */}
          <div 
            className="player"
            style={{
              transform: `translate3d(${player.x * (isMobile ? 15 : 20)}px, ${player.y * (isMobile ? 15 : 20)}px, ${player.z * (isMobile ? 15 : 20)}px)`
            }}
          >
            🧑‍🚀
          </div>

          {/* Blocks */}
          {visibleBlocks.map((block, index) => {
            const textureData = minecraftTextures[block.type as keyof typeof minecraftTextures];
            return (
              <div
                key={`${block.x}-${block.y}-${block.z}`}
                className={`world-block ${block.type} minecraft-block`}
                style={{
                  transform: `translate3d(${block.x * (isMobile ? 15 : 20)}px, ${block.y * (isMobile ? 15 : 20)}px, ${block.z * (isMobile ? 15 : 20)}px)`,
                  width: isMobile ? '15px' : '20px',
                  height: isMobile ? '15px' : '20px',
                  backgroundColor: textureData?.color,
                  fontSize: isMobile ? '8px' : '10px'
                }}
                onClick={() => mineBlock(block.x, block.y, block.z)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  placeBlock(block.x, block.y + 1, block.z);
                }}
              >
                {textureData?.emoji}
              </div>
            );
          })}

          {/* Particles */}
          {particles.map(particle => (
            <div
              key={particle.id}
              className="particle"
              style={{
                transform: `translate3d(${particle.x * (isMobile ? 15 : 20)}px, ${particle.y * (isMobile ? 15 : 20)}px, ${particle.z * (isMobile ? 15 : 20)}px)`,
                backgroundColor: particle.color,
                width: `${particle.size}px`,
                height: `${particle.size}px`,
                opacity: particle.life / 30
              }}
            />
          ))}
        </div>
      </div>

      {/* Mobile Controls */}
      {isMobile && (
        <div className="mobile-controls">
          <div className="movement-pad">
            <button onClick={() => movePlayer(0, 0, -1)}>↑</button>
            <div className="middle-row">
              <button onClick={() => movePlayer(-1, 0, 0)}>←</button>
              <button onClick={() => movePlayer(0, 1, 0)}>🔼</button>
              <button onClick={() => movePlayer(1, 0, 0)}>→</button>
            </div>
            <button onClick={() => movePlayer(0, 0, 1)}>↓</button>
          </div>
          <div className="action-buttons">
            <button onClick={() => movePlayer(0, -1, 0)}>🔽</button>
            <button onClick={() => setShowInventory(!showInventory)}>🎒</button>
            <button onClick={() => setIsBuilding(!isBuilding)}>{isBuilding ? '⛏️' : '🔨'}</button>
          </div>
        </div>
      )}

      {/* Weather Effects */}
      {weather === 'rain' && (
        <div className="weather-rain">
          {Array.from({ length: isMobile ? 50 : 100 }).map((_, i) => (
            <div 
              key={i} 
              className="raindrop" 
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`
              }} 
            />
          ))}
        </div>
      )}

      {/* Inventory Modal */}
      {showInventory && (
        <div className="inventory-modal" onClick={() => setShowInventory(false)}>
          <div className="inventory-grid" onClick={(e) => e.stopPropagation()}>
            <h3>Inventory</h3>
            <button onClick={() => setShowInventory(false)}>×</button>
            <div className="inventory-items">
              {inventory.map((item, index) => (
                <div key={index} className="inventory-item">
                  <span>{minecraftTextures[item.type as keyof typeof minecraftTextures]?.emoji || '📦'}</span>
                  <span>{item.type.replace('_', ' ').toUpperCase()}</span>
                  <span>{item.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Controls */}
      <div className="controls">
        {!isMobile && (
          <div className="desktop-controls">
            <p><strong>WASD:</strong> Move | <strong>Space:</strong> Jump | <strong>Shift:</strong> Down</p>
            <p><strong>E:</strong> Inventory | <strong>1-9:</strong> Select Item | <strong>Left Click:</strong> Mine</p>
          </div>
        )}
        {isMobile && (
          <div className="mobile-help">
            <p><strong>Swipe:</strong> Move | <strong>Tap Block:</strong> Mine | <strong>Use Controls:</strong> Build</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StarCraft3D;
