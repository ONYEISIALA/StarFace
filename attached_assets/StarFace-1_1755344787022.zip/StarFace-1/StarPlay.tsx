import React, { useState } from 'react';
import MultiplayerTicTacToe from './MultiplayerTicTacToe';
import MultiplayerMemoryFight from './MultiplayerMemoryFight';
import MultiplayerBottleFlip from './MultiplayerBottleFlip';
import StarCraft3D from './StarCraft3D';
import ColorSpread from './ColorSpread';
import ColorWars from './ColorWars';
import SpeedClick from './SpeedClick';
import NumberTap from './NumberTap';
import QuickMathDuel from './QuickMathDuel';
import ConnectFour from './ConnectFour';

const StarPlay: React.FC = () => {
  const [roomCode, setRoomCode] = useState('');
  const [player, setPlayer] = useState<'X' | 'O' | null>(null);
  const [gameSelected, setGameSelected] = useState<
    'tictactoe' | 'memoryfight' | 'bottleflip' | 'starcraft2d' | 'colorspread' | 'colorwars' | 'speedclick' | 'numbertap' | 'quickmath' | 'connectfour' | null
  >(null);
  const [joinedRoom, setJoinedRoom] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);

  const createRoom = () => {
    const code = Math.random().toString(36).substring(2, 7).toUpperCase();
    setRoomCode(code);
    setPlayer('X');
    setJoinedRoom(true);
  };

  const joinRoom = () => {
    if (roomCode.trim().length === 5) {
      setPlayer('O');
      setJoinedRoom(true);
    }
  };

  const handleGameSelect = (
    game: 'tictactoe' | 'memoryfight' | 'bottleflip' | 'starcraft2d' | 'colorspread' | 'colorwars' | 'speedclick' | 'numbertap' | 'quickmath' | 'connectfour'
  ) => {
    setGameSelected(game);
  };

  const resetGame = () => {
    setRoomCode('');
    setPlayer(null);
    setGameSelected(null);
    setJoinedRoom(false);
  };

  return (
    <div style={containerStyle}>
      <h1>🌟 StarPlay Multiplayer</h1>

      {player && (
        <>
          <p>Room Code: <strong>{roomCode}</strong></p>
          <p>You are Player: <strong>{player}</strong></p>
        </>
      )}

      {!player ? (
        <div>
          <button onClick={createRoom} style={buttonStyle}>🎮 Create Game Room</button>
          <p>OR</p>
          <input
            placeholder="Enter Room Code"
            value={roomCode}
            onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
            maxLength={5}
            style={inputStyle}
          />
          <button onClick={joinRoom} style={buttonStyle}>🔑 Join Room</button>
        </div>
      ) : !gameSelected ? (
        <div>
          <h2>Select a Game:</h2>
          <div style={gameGridStyle}>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('tictactoe')}>✖️ Tic Tac Toe</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('memoryfight')}>🧠 Memory Fight</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('bottleflip')}>🍾 Bottle Flip</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('colorwars')}>🎨 Color Wars</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('speedclick')}>⚡ Speed Click</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('numbertap')}>🔢 Number Tap</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('quickmath')}>🧮 Quick Math</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('connectfour')}>🔴 Connect Four</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('starcraft2d')}>🌍 StarCraft 2D</button>
            <button style={gameButtonStyle} onClick={() => handleGameSelect('colorspread')}>🎨 Color Spread</button>
          </div>
        </div>
      ) : (
        <>
          <button onClick={() => setShowInstructions(prev => !prev)} style={infoButtonStyle}>
            {showInstructions ? 'Hide' : 'Show'} Instructions
          </button>
          {showInstructions && (
            <div style={instructionBox}>
              <h3>📘 Game Instructions</h3>
              {gameSelected === 'tictactoe' && <p>Take turns placing X and O. First to align 3 wins!</p>}
              {gameSelected === 'memoryfight' && <p>Flip matching cards before your opponent does.</p>}
              {gameSelected === 'bottleflip' && <p>Click flip! Land as many as possible. Challenge your opponent!</p>}
              {gameSelected === 'colorwars' && <p>Paint as much territory as possible in 2 minutes! Most coverage wins!</p>}
              {gameSelected === 'speedclick' && <p>Click the shapes as fast as possible! First to 10 wins!</p>}
              {gameSelected === 'numbertap' && <p>Tap numbers 1-25 in order as fast as possible!</p>}
              {gameSelected === 'quickmath' && <p>Solve math problems quickly! First to 10 correct answers wins!</p>}
              {gameSelected === 'connectfour' && <p>Connect 4 pieces in a row (horizontal, vertical, or diagonal) to win!</p>}
              {gameSelected === 'starcraft2d' && <p>Use WASD to move. Click to place, right-click to remove. Collect blocks and use inventory tools!</p>}
              {gameSelected === 'colorspread' && <p>Paint the board with your color. This version is offline/local only.</p>}
            </div>
          )}

          {gameSelected === 'tictactoe' && (
            <MultiplayerTicTacToe roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'memoryfight' && (
            <MultiplayerMemoryFight roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'bottleflip' && (
            <MultiplayerBottleFlip roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'colorwars' && (
            <ColorWars roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'speedclick' && (
            <SpeedClick roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'numbertap' && (
            <NumberTap roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'quickmath' && (
            <QuickMathDuel roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'connectfour' && (
            <ConnectFour roomCode={roomCode} player={player} />
          )}
          {gameSelected === 'starcraft2d' && (
            <StarCraft3D />
          )}
          {gameSelected === 'colorspread' && (
            <ColorSpread roomCode={roomCode} player={player} />
          )}

          <button onClick={resetGame} style={resetButtonStyle}>🔁 Reset</button>
        </>
      )}
    </div>
  );
};

// Styles
const containerStyle: React.CSSProperties = {
  textAlign: 'center',
  padding: 20,
  backgroundColor: '#1e1f22',
  minHeight: '100vh',
  color: '#ffffff',
};

const buttonStyle: React.CSSProperties = {
  padding: '12px 20px',
  borderRadius: '8px',
  backgroundColor: '#5865F2',
  color: 'white',
  border: 'none',
  fontWeight: 'bold',
  cursor: 'pointer',
  margin: '10px',
};

const gameButtonStyle: React.CSSProperties = {
  ...buttonStyle,
  backgroundColor: '#10b981',
  fontSize: '1.2rem',
  minWidth: '200px',
  margin: '8px',
};

const inputStyle: React.CSSProperties = {
  padding: '10px 12px',
  borderRadius: '6px',
  border: 'none',
  fontSize: '16px',
  marginBottom: '10px',
};

const resetButtonStyle: React.CSSProperties = {
  ...buttonStyle,
  backgroundColor: '#ef4444',
  marginTop: '20px',
};

const infoButtonStyle: React.CSSProperties = {
  ...buttonStyle,
  backgroundColor: '#facc15',
};

const instructionBox: React.CSSProperties = {
  backgroundColor: '#333',
  padding: '15px',
  borderRadius: '8px',
  margin: '10px auto',
  maxWidth: '500px',
  textAlign: 'left',
};

const gameGridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
  gap: '15px',
  maxWidth: '800px',
  margin: '0 auto',
  padding: '20px',
};

export default StarPlay;
