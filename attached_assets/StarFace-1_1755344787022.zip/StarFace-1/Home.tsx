import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Home: React.FC = () => {
  const navigate = useNavigate();

  // 🔒 Lockdown state
  const [unlocked, setUnlocked] = useState(isUnlocked());

  useEffect(() => {
    const t = setInterval(() => setUnlocked(isUnlocked()), 1000);
    return () => clearInterval(t);
  }, []);

  const featureCards = [
    { label: "StarFace Social", icon: "🌍", route: "/social", color: "#38bdf8" },
    { label: "Create Avatar", icon: "🎨", route: "/avatar", color: "#60a5fa" },
    { label: "StarPlay", icon: "🌟", route: "/starplay", color: "#facc15" },
    { label: "Learning Lounge", icon: "📘", route: "/lounge", color: "#34d399" },
    { label: "Chat", icon: "💬", route: "/chat", color: "#f472b6" },
    { label: "Profile", icon: "🧑", route: "/profile", color: "#a78bfa" },
    { label: "Parental Control", icon: "🔐", route: "/parent", color: "#fb923c" },
  ];

  return (
    <div style={{
      padding: "40px",
      maxWidth: "1000px",
      margin: "auto",
      fontFamily: "'Segoe UI', sans-serif",
      position: "relative"
    }}>
      {/* Welcome Header */}
      <div style={{
        textAlign: "center",
        marginBottom: "40px",
        background: "#1e3a8a",
        color: "#fff",
        padding: "25px",
        borderRadius: "20px",
        boxShadow: "0 8px 16px rgba(0,0,0,0.15)"
      }}>
        <h1 style={{ fontSize: "32px", marginBottom: "5px" }}>👋 Welcome to StarFace</h1>
        <p style={{ fontSize: "16px", color: "#cbd5e1" }}>
          A safe social world for the next generation of young stars — share, play, and connect with star friends.
        </p>
      </div>

      {/* Feature Cards */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))",
        gap: "25px",
      }}>
        {featureCards.map((item, index) => (
          <div
            key={index}
            onClick={() => navigate(item.route)}
            style={{
              backgroundColor: item.color,
              color: "#fff",
              padding: "25px 20px",
              borderRadius: "18px",
              textAlign: "center",
              cursor: "pointer",
              transition: "transform 0.2s ease, box-shadow 0.3s ease",
              boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLDivElement).style.transform = "scale(1.05)";
              (e.currentTarget as HTMLDivElement).style.boxShadow = "0 8px 20px rgba(0,0,0,0.2)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLDivElement).style.transform = "scale(1)";
              (e.currentTarget as HTMLDivElement).style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)";
            }}
          >
            <div style={{ fontSize: "40px", marginBottom: "10px" }}>{item.icon}</div>
            <div style={{ fontSize: "18px", fontWeight: "bold" }}>{item.label}</div>
          </div>
        ))}
      </div>

      {/* 🔒 Lock Overlay */}
      {!unlocked && (
        <div style={{
          position: "fixed", inset: 0,
          background: "#0a1a2fE6", backdropFilter: "blur(4px)",
          display: "grid", placeItems: "center",
          zIndex: 9999
        }}>
          <div style={{
            width: 420, maxWidth: "92vw",
            background: "#102a4c", color: "#eaf2ff",
            border: "1px solid #1b3d66",
            borderRadius: 16, padding: 20,
            boxShadow: "0 20px 60px rgba(0,0,0,0.45)",
            textAlign: "center"
          }}>
            <h3 style={{ marginTop: 0, display: "flex", alignItems: "center", gap: 10, justifyContent: "center" }}>
              <span style={{ width: 10, height: 10, background: "#ffd60a", borderRadius: "50%" }} />
              Locked
            </h3>
            <p style={{ color: "#b6c2d1", marginTop: 6 }}>
              Screen time is not active. Start a session to use the app.
            </p>
            <button
              onClick={() => navigate("/parent")}
              style={{
                width: "100%", padding: "12px 16px",
                border: "none", borderRadius: 12,
                background: "linear-gradient(90deg, #ffd60a, #e6bf00)",
                color: "#1a1a1a", fontWeight: 700,
                cursor: "pointer", marginTop: 10
              }}
            >
              Go to Parental Control
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper to check parental control unlock
function isUnlocked() {
  const until = Number(localStorage.getItem("parentalAllowedUntil") || 0);
  return until > Date.now();
}

export default Home;
