import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./Home";
import Profile from "./Profile";
import Login from "./Login";
import Register from "./Register";
import Chat from "./Chat";
import AvatarCreator from "./AvatarCreator";
import StarPlay from "./StarPlay";
import LearningLounge from "./LearningLounge";
import ParentControl from "./ParentControl";
import Social from "./Social";
import StarCraft3D from "./StarCraft3D";
import Quiz from "./Quiz";
import WordUnscramble from "./WordUnscramble";
import LogicPuzzle from "./LogicPuzzle";
import SpotTheDifference from "./SpotTheDifference";
import CreateContent from "./CreateContent";
import Leaderboard from "./Leaderboard";

const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/avatar" element={<AvatarCreator />} />
        <Route path="/starplay" element={<StarPlay />} />
        <Route path="/lounge" element={<LearningLounge />} />
        <Route path="/parent" element={<ParentControl />} />
        <Route path="/social" element={<Social />} />
        <Route path="/starcraft3d" element={<StarCraft3D />} />
        <Route path="/quiz" element={<Quiz />} />
        <Route path="/wordscramble" element={<WordUnscramble />} />
        <Route path="/logicpuzzle" element={<LogicPuzzle />} />
        <Route path="/spotthedifference" element={<SpotTheDifference />} />
        <Route path="/create" element={<CreateContent />} />
        <Route path="/leaderboard" element={<Leaderboard />} />
      </Routes>
    </Router>
  );
};

export default App;
